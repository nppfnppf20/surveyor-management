# Surveyor Timeline Application

This is a web application for managing surveyor quotes, projects, and a calendar for scheduling.

## Setup Instructions

### 1. Set up Supabase

1. Go to [Supabase](https://supabase.com) and sign up or log in.
2. Create a new project.
3. Once your project is created, go to the SQL Editor.
4. Run the following SQL to create the necessary tables:

```sql
-- Create quotes table
CREATE TABLE quotes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discipline VARCHAR NOT NULL,
  survey_type VARCHAR NOT NULL,
  organization VARCHAR NOT NULL,
  contact VARCHAR NOT NULL,
  email VARCHAR NOT NULL,
  turnaround_date DATE,
  status VARCHAR NOT NULL,
  instruction VARCHAR NOT NULL
);

-- Create line_items table
CREATE TABLE line_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id UUID REFERENCES quotes(id) ON DELETE CASCADE,
  description VARCHAR NOT NULL,
  amount NUMERIC NOT NULL
);

-- Create projects table
CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_type VARCHAR NOT NULL,
  organization VARCHAR NOT NULL,
  contact VARCHAR NOT NULL,
  email VARCHAR NOT NULL,
  site_visit_date DATE,
  first_draft_date DATE,
  final_report_date DATE,
  status VARCHAR NOT NULL,
  notes TEXT,
  quote_id UUID REFERENCES quotes(id) ON DELETE SET NULL
);

-- Create calendar_notes table
CREATE TABLE calendar_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  text TEXT,
  is_target_date BOOLEAN DEFAULT FALSE,
  is_reports_in BOOLEAN DEFAULT FALSE
);

-- Create reviews table
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization VARCHAR NOT NULL,
  name VARCHAR NOT NULL,
  quality INTEGER DEFAULT 0,
  responsiveness INTEGER DEFAULT 0,
  delivered_on_time INTEGER DEFAULT 0,
  overall_review INTEGER DEFAULT 0,
  notes TEXT,
  email VARCHAR NOT NULL
);
```

### 2. Configure the Application

1. Open the `src/supabase.js` file.
2. Replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY` with your actual Supabase URL and anon key.
   - You can find these in your Supabase dashboard under Project Settings > API.

### 3. Run the Application

1. Open the `index.html` file in a web browser.
2. The application should load and connect to your Supabase database.

## Features

- **Quotes Management**: Create, edit, and delete quotes for surveying services.
- **Project Tracking**: Track instructed surveys with status updates and notes.
- **Calendar View**: Visualize project deadlines and important dates.
- **Project Information**: Store detailed project specifications and files.
- **Surveyor Reviews**: Rate and review surveyors based on their performance.

## Data Structure

- **Quotes**: Contains basic information about quotes, including discipline, survey type, organization, contact details, and status.
- **Line Items**: Stores the line items associated with each quote, including description and amount.
- **Projects**: Tracks instructed surveys, including site visit dates, draft dates, and final report dates.
- **Calendar Notes**: Stores notes and events for specific dates in the calendar.
- **Reviews**: Contains performance reviews for surveyors.

## Troubleshooting

If you encounter any issues:

1. Check the browser console for error messages.
2. Verify that your Supabase URL and anon key are correct.
3. Ensure that the tables have been created correctly in your Supabase database.
4. Check that your Supabase project has the correct permissions set up for the tables.

## License

This project is licensed under the MIT License. 