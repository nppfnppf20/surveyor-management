// Supabase client initialization
const createClient = () => {
  // Replace these with your actual Supabase URL and anon key
  // You can find these in your Supabase dashboard:
  // 1. Go to https://supabase.com and sign in
  // 2. Select your project
  // 3. Go to Project Settings > API
  // 4. Copy the URL and anon key from the "Project API keys" section
  const supabaseUrl = 'https://ioukidwpwrmgwoppnwnv.supabase.co'; // e.g. 'https://abcdefghijklmnopqrst.supabase.co'
  const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlvdWtpZHdwd3JtZ3dvcHBud252Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE4NDc0MzUsImV4cCI6MjA1NzQyMzQzNX0.QI4kL_y3WTj1gGO6kcKGhAO-wEGLnVfyhn2EC0mayKU'; // e.g. 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
  
  // Create a supabase client
  return {
    from: (table) => ({
      select: (columns) => ({
        then: (callback) => {
          fetch(`${supabaseUrl}/rest/v1/${table}?select=${columns || '*'}`, {
            headers: {
              'apikey': supabaseKey,
              'Authorization': `Bearer ${supabaseKey}`,
              'Content-Type': 'application/json'
            }
          })
          .then(response => response.json())
          .then(data => callback({ data, error: null }))
          .catch(error => callback({ data: null, error }));
        }
      }),
      insert: (data) => ({
        then: (callback) => {
          fetch(`${supabaseUrl}/rest/v1/${table}`, {
            method: 'POST',
            headers: {
              'apikey': supabaseKey,
              'Authorization': `Bearer ${supabaseKey}`,
              'Content-Type': 'application/json',
              'Prefer': 'return=representation'
            },
            body: JSON.stringify(data)
          })
          .then(response => response.json())
          .then(data => callback({ data, error: null }))
          .catch(error => callback({ data: null, error }));
        }
      }),
      update: (data) => ({
        eq: (column, value) => ({
          then: (callback) => {
            fetch(`${supabaseUrl}/rest/v1/${table}?${column}=eq.${value}`, {
              method: 'PATCH',
              headers: {
                'apikey': supabaseKey,
                'Authorization': `Bearer ${supabaseKey}`,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
              },
              body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => callback({ data, error: null }))
            .catch(error => callback({ data: null, error }));
          }
        })
      }),
      delete: () => ({
        eq: (column, value) => ({
          then: (callback) => {
            fetch(`${supabaseUrl}/rest/v1/${table}?${column}=eq.${value}`, {
              method: 'DELETE',
              headers: {
                'apikey': supabaseKey,
                'Authorization': `Bearer ${supabaseKey}`,
                'Content-Type': 'application/json'
              }
            })
            .then(response => response.json())
            .then(data => callback({ data, error: null }))
            .catch(error => callback({ data: null, error }));
          }
        })
      })
    })
  };
};

// Create and export the Supabase client
const supabase = createClient();

// Export the client
window.supabase = supabase; 